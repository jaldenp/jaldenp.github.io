﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class SwingMelee : MonoBehaviour {

	public int playerNum = 0;
	private InputDevice controller;

	private ChangeSprite changeSprite;


	private bool cooldown = false;
	public float cooldownTime;
	private float cooldownCounter;

	private PlayerAction playerAction;

	public float swingTime;

	public List<GameObject> weapons = new List<GameObject>();

	private Vector3 startPosition;
	public float swingDistance;

	private GameObject swingingWeapon;
	private Vector3 targetPostion;

	private GameController gameController;



	// Use this for initialization
	void Awake () {
		controller = InputManager.Devices[playerNum];
		playerAction = GetComponentInParent<PlayerAction>();
		changeSprite = GetComponent<ChangeSprite>();

		startPosition = weapons[0].transform.localPosition;
		targetPostion = startPosition + new Vector3(swingDistance, 0f, 0f);
		gameController = GameObject.Find("GameController").GetComponent<GameController>();

	}
	
	// Update is called once per frame
	void Update () {

		if (!gameController.gameOver) {

			if (!cooldown && !playerAction.isPerformingAction() && controller.Action3) {
				playerAction.performAction();
				swingingWeapon = weapons[changeSprite.spriteNum];

				swingingWeapon.SetActive(true);

				StartCoroutine(swingWeapon());
			}

			if (cooldown) {
				if (cooldownCounter > 0) {
					cooldownCounter -= Time.deltaTime;
				}
				else {
					cooldown = false;
				}
			}
		}
	}

	IEnumerator swingWeapon(){
		Vector3 currentPos = swingingWeapon.transform.localPosition;
		float t = 0f;

		while (t < 1){
			t += Time.deltaTime / swingTime;
			swingingWeapon.transform.localPosition = Vector3.Lerp(currentPos, targetPostion, t);
			yield return null;
		}

		swingingWeapon.SetActive(false);
		swingingWeapon.transform.localPosition = startPosition;

		playerAction.performAction();
		cooldown = true;
		cooldownCounter = cooldownTime;
	}
}
