﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicControl : MonoBehaviour {

	public AudioClip fightMusic;
	public AudioClip clashMusic;

	private AudioSource audioSource;

	// Use this for initialization
	void Awake () {
		audioSource = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	public void startClash() {
		audioSource.clip = clashMusic;
		audioSource.Play();
	}

	public void endClash() {
		audioSource.clip = fightMusic;
		audioSource.Play();
	}
}
