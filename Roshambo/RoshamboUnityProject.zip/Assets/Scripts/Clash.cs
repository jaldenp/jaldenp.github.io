﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;
using UnityEngine.UI;

public class Clash : MonoBehaviour {

	private InputDevice controller;

	private GameController gameController;

	public Image rageBar;

	private float ragePercentage = 0f;

	private float maxRagePercentage = 30f;

	private ClashEvent clashEvent;

	// Use this for initialization
	void Start () {
		controller = InputManager.Devices[GetComponent<PlayerNum>().playerNum];
		gameController = GameObject.Find("GameController").GetComponent<GameController>();
		clashEvent = gameController.gameObject.GetComponent<ClashEvent>();
	}
	
	// Update is called once per frame
	void Update () {
		if (!gameController.ignoreInput && ragePercentage >= maxRagePercentage) {
			if (controller.LeftTrigger) {
				// reset Percentage
				ragePercentage = 0;
				rageBar.fillAmount = 0;

				// trigger Clash System
				clashEvent.StartClash();
			}
		}
	}

	public void IncrementRage(int increase) {
		ragePercentage += increase;

		rageBar.fillAmount = ragePercentage / maxRagePercentage;
	}
}
