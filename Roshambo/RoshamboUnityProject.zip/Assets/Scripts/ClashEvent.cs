﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using InControl;

public class ClashEvent : MonoBehaviour {

	public GameObject clashUI;

	public GameObject clashCountdownObject;

	public Text clashCountdown;

	private GameController gameController;

	public GameObject pOneQuestionMark;
	public GameObject pTwoQuestionMark;

	public List<PlayerHealth> playerHealths = new List<PlayerHealth>();

	public List<GameObject> PlayerOneIcons = new List<GameObject>();

	public List<GameObject> PlayerTwoIcons = new List<GameObject>();

	private bool waitForInputs = false;

	private InputDevice controller1;
	private InputDevice controller2;

	private int playerOneChoice = -1;
	private int playerTwoChoice = -1;

	private char loser;

	public List<GameObject> ClashAttacks = new List<GameObject>();

	private MusicControl musicControl;

	private Vector3 offset = new Vector3(0 , 5f , 0);

	// Use this for initialization
	void Start () {
		gameController = GetComponent<GameController>();

		controller1 = InputManager.Devices[0];
		controller2 = InputManager.Devices[1];

		musicControl = GetComponent<MusicControl>();
	}
	
	// Update is called once per frame
	void Update () {
		if (playerOneChoice != -1 && playerTwoChoice != -1) {
			// call Clash Resolution Function
			StartCoroutine(ClashResolution(playerOneChoice, playerTwoChoice));

			waitForInputs = false;
			playerOneChoice = -1;
			playerTwoChoice = -1;
		}

		if (waitForInputs) {
			if (controller1.Action3) {
				playerOneChoice = 0;
				pOneQuestionMark.SetActive(true);
			}
			else if (controller1.Action4) {
				playerOneChoice = 1;
				pOneQuestionMark.SetActive(true);
			}
			else if (controller1.Action2) {
				playerOneChoice = 2;
				pOneQuestionMark.SetActive(true);
			}

			if (controller2.Action3) {
				playerTwoChoice = 0;
				pTwoQuestionMark.SetActive(true);
			}
			else if (controller2.Action4) {
				playerTwoChoice = 1;
				pTwoQuestionMark.SetActive(true);
			}
			else if (controller2.Action2) {
				playerTwoChoice = 2;
				pTwoQuestionMark.SetActive(true);
			}
		}
	}

	public void StartClash() {
		clashUI.SetActive(true);

		gameController.TogglePlayerControls();

		// set velocity of players to 0
		playerHealths[0].gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
		playerHealths[1].gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;

		// start music
		musicControl.startClash();

		// make players invincible
		playerHealths[0].invincible = true;
		playerHealths[1].invincible = true;

		StartCoroutine(CountDown());
	}

	IEnumerator CountDown() {
		yield return new WaitForSeconds(1.0f);

		clashCountdownObject.SetActive(true);
		
		yield return new WaitForSeconds(1.0f);

		clashCountdown.text = "Paper";

		yield return new WaitForSeconds(1.0f);

		clashCountdown.text = "Scissors";

		yield return new WaitForSeconds(1.0f);
		
		clashCountdown.text = "SHOOT";

		// set bool to watch for inputs
		waitForInputs = true;
	}

	private void displayWinner(char playerNum) {
		clashCountdown.text = "Player " + playerNum + " wins";
	}

	IEnumerator ClashResolution(int p1Choice, int p2Choice) {
		yield return new WaitForSeconds(1.0f);

		// reveal the user's choices
		pOneQuestionMark.SetActive(false);
		pTwoQuestionMark.SetActive(false);

		Debug.Log(p1Choice);
		Debug.Log(p2Choice);
		PlayerOneIcons[p1Choice].SetActive(true);
		PlayerTwoIcons[p2Choice].SetActive(true);

		yield return new WaitForSeconds(1.0f);

		// Determine who won
		if (p1Choice == p2Choice) {
			// tie 
			clashCountdown.text = "TIE!!!!";
			loser = '0';
		}
		else if (p1Choice == 0 && p2Choice == 1) {
			// player 2 wins
			displayWinner('2');
			loser = '1';
		}
		else if (p1Choice == 1 && p2Choice == 0) {
			// player 1 wins
			displayWinner('1');
			loser = '2';
		}
		else if (p1Choice == 0 && p2Choice == 2) {
			// player 1 wins
			displayWinner('1');
			loser = '2';
		}
		else if (p1Choice == 2 && p2Choice == 0) {
			// player 2 wins
			displayWinner('2');
			loser = '1';
		}
		else if (p1Choice == 1 && p2Choice == 2) {
			// player 2 wins
			displayWinner('2');
			loser = '1';
		}
		else if (p1Choice == 2 && p2Choice == 1) {
			// player 1 wins
			displayWinner('1');
			loser = '2';
		}

		yield return new WaitForSeconds(1.5f);

		// call special attack function
		if (loser != '0') {
			if (loser == '1') {
				playerHealths[0].invincible = false;
				Instantiate(ClashAttacks[p2Choice],
							playerHealths[0].gameObject.transform.position + offset,
							playerHealths[0].gameObject.transform.rotation);
			}
			else {
				playerHealths[1].invincible = false;
				Instantiate(ClashAttacks[p1Choice],
							playerHealths[1].gameObject.transform.position + offset,
							playerHealths[1].gameObject.transform.rotation);
			}
			yield return new WaitForSeconds(2.0f);
		}

		clashCountdown.text = "Rock";
		clashCountdownObject.SetActive(false);

		PlayerOneIcons[p1Choice].SetActive(false);
		PlayerTwoIcons[p2Choice].SetActive(false);

		clashUI.SetActive(false);

		playerHealths[0].invincible = false;
		playerHealths[1].invincible = false;

		// change back music
		musicControl.endClash();

		gameController.TogglePlayerControls();
	}


}
