﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;
public class OpenShield : MonoBehaviour {
	public int playerNum = 0;
	private InputDevice controller;

	public List<GameObject> shields = new List<GameObject>();

	private ChangeSprite changeSprite;

	public float holdShieldTime;
	private float holdCounter;

	private bool cooldown;
	public float cooldownTime;
	private float cooldownCounter;

	private GameObject currentShield;

	private bool isShielding = false;

	private PlayerAction playerAction;

	private GameController gameController;


	// Use this for initialization
	void Awake () {
		controller = InputManager.Devices[playerNum];
		changeSprite = GetComponent<ChangeSprite>();
		playerAction = GetComponentInParent<PlayerAction>();
		gameController = GameObject.Find("GameController").GetComponent<GameController>();

	}
	
	// Update is called once per frame
	void Update () {

		if (!gameController.gameOver) {
		
			if (!cooldown && !playerAction.isPerformingAction() && controller.Action4) {

				currentShield = shields[changeSprite.spriteNum];

				currentShield.SetActive(true);

				holdCounter = holdShieldTime;
				playerAction.performAction();
				isShielding = true;
			}

			if (controller.Action4 && isShielding) {
				if (holdCounter > 0){
					holdCounter -= Time.deltaTime;
				}
				else {
					isShielding = false;
					playerAction.performAction();
					cooldown = true;
					cooldownCounter = cooldownTime;
					currentShield.SetActive(false);
				}
			}
			else if (isShielding) {
				isShielding = false;
				playerAction.performAction();
				cooldown = true;
				cooldownCounter = cooldownTime;
				currentShield.SetActive(false);
			}

			if (cooldown){
				if (cooldownCounter > 0){
					cooldownCounter -= Time.deltaTime;
				}
				else {
					cooldown = false;
				}
			}
		}
	}
}
