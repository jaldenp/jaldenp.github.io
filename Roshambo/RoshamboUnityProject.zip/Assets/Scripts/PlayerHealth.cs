﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerHealth : MonoBehaviour {

	private int remainingHealth = 100;

	//public Text healthText;
	public Image healthBar;

	public float iframeTime;

	public bool invincible = false;

	private Color currentColor;

	private GameController gameController;

	private Animator animator;

	private Rigidbody rb;

	public float knockbackForce;

	// Use this for initialization
	void Start () {
		gameController = GameObject.Find("GameController").GetComponent<GameController>();
		animator = GetComponent<Animator>();
		rb = GetComponent<Rigidbody>();
	}

	public void takeDamage(int damageValue) {
		remainingHealth -= damageValue;

		if (remainingHealth <= 0) {
			remainingHealth = 0;
			healthBar.fillAmount = 0;
			// trigger game over
			gameController.endGame(gameObject.tag[gameObject.tag.Length - 1]);

		}
		healthBar.fillAmount = remainingHealth / 100f;
		StartCoroutine(iframes());
	}

	public void gainHealth(int amount) {
		remainingHealth += amount;

		if (remainingHealth > 100) {
			remainingHealth = 100;
		}
		healthBar.fillAmount = remainingHealth / 100f;
	}

	IEnumerator iframes() {
		invincible = true;

		animator.SetLayerWeight(3, 1);

		// need to knockplayer back
		//rb.AddForce(-transform.right * knockbackForce, ForceMode.Impulse);

		yield return new WaitForSeconds(iframeTime);

		animator.SetLayerWeight(3, 0);

		invincible = false;
	}
}
