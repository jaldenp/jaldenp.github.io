﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class PlayerMove : MonoBehaviour {
	Rigidbody rb;

	public float moveSpeed;

	public LayerMask wallMask;

	public LayerMask netMask;

	public float rayCastDistance;

	private InputDevice controller;
	private GameController gameOver;

	private Animator animator;

	public bool player2 = false;
	

	// Use this for initialization
	void Awake () {
		rb = GetComponent<Rigidbody>();
		animator = GetComponent<Animator>();
		controller = InputManager.Devices[GetComponent<PlayerNum>().playerNum];

		gameOver = GameObject.Find("GameController").GetComponent<GameController>();
	}
	
	// Update is called once per frame
	void Update () {
		if (!gameOver.ignoreInput)
		{
			Vector3 velocity = rb.velocity;

			velocity.x = controller.LeftStickX * moveSpeed;
			if (velocity.x != 0) {
				animator.SetLayerWeight(1, 1);
			}
			else {
				animator.SetLayerWeight(1, 0);
			}

			bool right = false;
			// point raycast in right direction
			if (velocity.x > 0 && !player2) {
				right = true;
			}
			else if (velocity.x < 0 && player2) {
				right = true;
			}

			Debug.DrawRay(transform.position, transform.right * rayCastDistance * (right ? 1: -1), Color.red);
			// RayCast out to check for the wall
			if (Physics.Raycast(transform.position, transform.right * (right ? 1: -1), rayCastDistance, wallMask) || 
				Physics.Raycast(transform.position, transform.right * (right ? 1: -1), rayCastDistance, netMask)){
				velocity.x = 0f;
			}

			rb.velocity = velocity;
		}
	}
}
