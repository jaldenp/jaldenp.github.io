﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using InControl;

public class GameController : MonoBehaviour {


	public Text winnerText;
	public Text restartText;

	public bool ignoreInput = true;

	public bool gameOver = false;

	private InputDevice controller;
	private InputDevice controller1;

	public AudioClip churchBell;

	public Text fightCountdownText;

	void Start () {
		controller = InputManager.Devices[0];
		controller1 = InputManager.Devices[1];

		// start countdown
		StartCoroutine(FightCountDown());
	}

	IEnumerator FightCountDown() {
		yield return new WaitForSeconds(1.0f);

		fightCountdownText.text = "2";

		yield return new WaitForSeconds(1.0f);

		fightCountdownText.text = "1";

		yield return new WaitForSeconds(1.0f);

		fightCountdownText.text = "FIGHT!!!";

		// play Church bell
		AudioSource.PlayClipAtPoint(churchBell, new Vector3(0,0,0));

		ignoreInput = false;

		yield return new WaitForSeconds(1.0f);
		fightCountdownText.gameObject.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		if (gameOver) {
			if (controller.Action1) {
				SceneManager.LoadScene("Fight");
			}
			// watch for B to go back to main menu
			if (controller.Action2) {
				SceneManager.LoadScene("Main Menu");
			}
		}

	}

	public void TogglePlayerControls() {
		ignoreInput = !ignoreInput;
	}

	public void endGame(char loser){
		
		ignoreInput = true;

		char winner;

		if (loser == '1') {
			winner = '2';
		}
		else {
			winner = '1';
		}

		winnerText.text = "Player " + winner.ToString() + " Wins!";
		winnerText.gameObject.SetActive(true);

		StartCoroutine(RestartGameDelay());
	}

	IEnumerator RestartGameDelay() {
		yield return new WaitForSeconds(2.0f);

		restartText.gameObject.SetActive(true);

		gameOver = true;
	}
}
