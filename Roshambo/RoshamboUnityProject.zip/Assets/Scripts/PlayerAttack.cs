﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class PlayerAttack : MonoBehaviour {

	private GameController gameController;

	private PlayerDirection playerDirection;

	private InputDevice controller;

	public List<GameObject> projectiles = new List<GameObject>();
	public float projectileSpeed;

	public Vector3 projectOffset;

	private bool cooldown = false;

	// Use this for initialization
	void Start () {
		gameController = GameObject.Find("GameController").GetComponent<GameController>();
		controller = InputManager.Devices[GetComponent<PlayerNum>().playerNum];
		playerDirection = GetComponent<PlayerDirection>();
	}

	void LaunchProjectile(int index){
		Vector3 directionProjectOffset = projectOffset;
		directionProjectOffset.x = directionProjectOffset.x * (playerDirection.right ? 1: -1);
		Vector3 offset = Vector3.right * (playerDirection.right ? 1: -1) + directionProjectOffset;
		GameObject launchedProjectile = Instantiate(projectiles[index],
													transform.position + offset,
													transform.rotation);
		// give it velocity
		launchedProjectile.GetComponent<Rigidbody>().velocity = new Vector3(projectileSpeed * (playerDirection.right ? 1: -1), 0, 0);

		// perform action
		StartCoroutine(PerformAction(1f));
	}
	
	// Update is called once per frame
	void Update () {

		if (!gameController.ignoreInput && !cooldown) {
		
			// X is Rock (Action 3)
			// Y is Paper (Action 4)
			// Z is Scissors (Action 2)
			// Ranged Attack
			if (controller.Action3) {
				// rock
				LaunchProjectile(0);
			}
			else if (controller.Action4){
				// paper
				LaunchProjectile(1);
			}
			else if (controller.Action2){
				// scissors
				LaunchProjectile(2);
			}
		}
	}

	IEnumerator PerformAction(float cooldownTime) {
		cooldown = true;

		// TODO: change sprite
		
		yield return new WaitForSeconds(cooldownTime);

		// TODO: change sprite

		cooldown = false;
	}
}
