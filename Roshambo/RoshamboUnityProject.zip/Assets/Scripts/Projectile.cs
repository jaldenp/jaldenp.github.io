﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Projectile : MonoBehaviour { 

	private PlayerDirection playerDirection;

	private PlayerAction playerAction;

	public float coolDownTime;
	private float counter;
	private bool cooldown = false;

	public int playerNum = 0;

	private InputDevice controller;

	public GameObject rock;
	public GameObject paperAirplane;
	public GameObject scissors;

	private List<GameObject> projectiles = new List<GameObject>();

	private ChangeSprite changeSprite;

	public float projectileSpeed;

	private GameController gameController;

	// Use this for initialization
	void Awake () {
		playerDirection = transform.parent.gameObject.GetComponentInParent<PlayerDirection>();
		playerAction = GetComponentInParent<PlayerAction>();
		controller = InputManager.Devices[playerNum];

		projectiles.Add(rock);
		projectiles.Add(paperAirplane);
		projectiles.Add(scissors);

		changeSprite = GetComponent<ChangeSprite>();
		gameController = GameObject.Find("GameController").GetComponent<GameController>();

	}
	
	// Update is called once per frame
	void Update () {

		if (!gameController.gameOver) {
			if (!cooldown && controller.Action2 && !playerAction.isPerformingAction()){
				Vector3 offset = Vector3.right * 0.3f * (playerDirection.right ? 1: -1);

				playerAction.performAction();

				// launch projectile
				GameObject launchedProjectile = Instantiate(projectiles[changeSprite.spriteNum],
															transform.position + offset,
															transform.rotation);

				// give it velocity
				launchedProjectile.GetComponent<Rigidbody>().velocity = new Vector3(projectileSpeed * (playerDirection.right ? 1: -1), 0, 0);

				cooldown = true;
				counter = coolDownTime;
			}

			if (cooldown){
				if (counter > 0){
					counter -= Time.deltaTime;
				}
				else {
					playerAction.performAction();
					cooldown = false;
				}
			}
		}
	}
}
