﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BounceOffWall : MonoBehaviour {

	private Rigidbody rb;
	public float forceMultiplier;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();

		Vector3 forceDirection = transform.right;

		// randomly goes down or up
		if (Random.Range(0, 100) >= 50) {
			forceDirection.y = -2.0f;
		}
		else {
			forceDirection.y = 2.0f;
		}


		rb.AddForce(forceDirection * forceMultiplier, ForceMode.Impulse);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
