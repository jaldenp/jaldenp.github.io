﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectilePaper : MonoBehaviour {

	public Sprite cutAirplane;

	private SpriteRenderer spriteRenderer;

	private Rigidbody rb;


	public GameObject paperBeatsRock;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		spriteRenderer = GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
 
	private void OnTriggerEnter(Collider other) {
		if (other.tag == "Paper") {
			Vector3 downward = new Vector3(0f, -3f, 0);
			rb.velocity = downward;
		}
		if (other.tag == "Scissors") {
			// change sprite to broken paper airplane
			// set velocity to down
			// remove box collider

			spriteRenderer.sprite = cutAirplane;

			Vector3 downward = new Vector3(0f, -3f, 0);
			rb.velocity = downward;

			gameObject.layer = LayerMask.NameToLayer("Falling");

			//StartCoroutine(DestroyAfterSeconds());
		}

		if (other.tag == "Rock") {
			// paper covers rock
			// spawn PaperBeatsRock Object that is traveling in the same direciton
			Instantiate(paperBeatsRock,
						transform.position,
						transform.rotation);
			Destroy(gameObject);
		}
	}

	IEnumerator DestroyAfterSeconds() {
		yield return new WaitForSeconds(1.5f);
		GameObject.Destroy(gameObject);
	}
}
