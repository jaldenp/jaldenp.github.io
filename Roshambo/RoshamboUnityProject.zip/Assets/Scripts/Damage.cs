﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour {

	private PlayerHealth playerHealth;

	private Clash playerClash;

	void Start() {
		playerHealth = GetComponent<PlayerHealth>();
		playerClash = GetComponent<Clash>();
	}

	// Use this for initialization
	void OnTriggerEnter(Collider other)
	{
		if (!playerHealth.invincible){
			if (LayerMask.LayerToName(other.gameObject.layer) == "Projectile") {
				playerHealth.takeDamage(8);
				playerClash.IncrementRage(8);
			}
			if (other.tag == "Clash") {
				playerHealth.takeDamage(20);
				playerClash.IncrementRage(5);
			}
		}
	}

	private void OnCollisionEnter(Collision other) {
		if (!playerHealth.invincible){
			if (LayerMask.LayerToName(other.gameObject.layer) == "Projectile") {
				playerHealth.takeDamage(8);
				playerClash.IncrementRage(8);
				Destroy(other.gameObject);
			}
		}
	}
}
