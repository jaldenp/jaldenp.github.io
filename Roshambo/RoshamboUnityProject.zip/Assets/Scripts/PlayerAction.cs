﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAction : MonoBehaviour {

	private bool preformingAction = false;
	
	public void performAction(){
		preformingAction = !preformingAction;
	}

	public bool isPerformingAction(){
		return preformingAction;
	}
}
