﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;
using UnityEngine.SceneManagement;

public class TutorialController : MonoBehaviour {

	private InputDevice controller;


	// Use this for initialization
	void Start () {
		controller = InputManager.Devices[0];
	}
	
	// Update is called once per frame
	void Update () {
		if (controller.Action2) {
			SceneManager.LoadScene("Main Menu");
		}
	}
}
