﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class ChangeSprite : MonoBehaviour {

	private SpriteRenderer spriteRenderer;

	public Sprite rock;

	public Sprite paper;

	public Sprite scissors;

	private List<Sprite> sprites = new List<Sprite>();

	public int spriteNum;

	private InputDevice controller;

	public int playerNum = 0;

	public float changeTime;
	private float changeTimeCounter;
	private bool cooldown = false;
	// Use this for initialization
	void Awake () {
		spriteRenderer = GetComponent<SpriteRenderer>();

		sprites.Add(rock);
		sprites.Add(paper);
		sprites.Add(scissors);

		controller = InputManager.Devices[playerNum];

	}
	
	// Update is called once per frame
	void Update () {

		if (!cooldown){
			if (controller.LeftBumper){
				// cycle left
				spriteNum++;
				if (spriteNum >= 3) {
					spriteNum = 0;
				}

				spriteRenderer.sprite = sprites[spriteNum];

				cooldown = true;
				changeTimeCounter = changeTime;
			}
			else if (controller.RightBumper){
				// cycle right
				spriteNum--;
				if (spriteNum < 0) {
					spriteNum = 2;
				}

				spriteRenderer.sprite = sprites[spriteNum];

				cooldown = true;
				changeTimeCounter = changeTime;
			}
		}
		else {
			if (changeTimeCounter > 0) {
				changeTimeCounter -= Time.deltaTime;
			}
			else {
				cooldown = false;
			}
		}
	}
}
