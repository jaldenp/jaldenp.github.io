﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOnContact : MonoBehaviour {
	void OnTriggerEnter(Collider other){
		if (other.tag == ("Player") || other.tag == "Wall") {
			Destroy(gameObject);
		}

		if (LayerMask.LayerToName(other.gameObject.layer) == "Shield" || 
			LayerMask.LayerToName(other.gameObject.layer) == "Ground") {
			Destroy(gameObject);
		}
	}
}
