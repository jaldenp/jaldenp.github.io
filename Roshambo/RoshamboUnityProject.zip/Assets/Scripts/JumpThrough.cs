﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpThrough : MonoBehaviour {

	public GameObject Player;

	public Vector3 feetOffset;

	private BoxCollider boxCollider;

	// Use this for initialization
	void Start () {
		boxCollider = GetComponent<BoxCollider>();
	}
	
	// Update is called once per frame
	void Update () {
		if ((Player.transform.position + feetOffset).y > transform.position.y) {
			boxCollider.enabled = true;
		}
		else {
			boxCollider.enabled = false;
		}
	}
}
