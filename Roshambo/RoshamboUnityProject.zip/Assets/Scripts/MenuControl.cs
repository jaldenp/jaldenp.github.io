﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;
using UnityEngine.SceneManagement;

public class MenuControl : MonoBehaviour {

	private InputDevice controller;

	private void Start() {
		controller = InputManager.Devices[0];
	}
	
	// Update is called once per frame
	void Update () {
		if (controller.Action1) {
			// load fight sceen
			SceneManager.LoadScene("Fight");
		}
		if (controller.Action2) {
			// load tutorial
			SceneManager.LoadScene("Tutorial");
		}
	}
}
