﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileRock : MonoBehaviour {

	private Rigidbody rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
	}

	private void OnTriggerEnter(Collider other) {
		if (other.tag == "Paper") {
			// destroy rock
			Destroy(gameObject);
		}

		if (other.tag == "Rock") {
			// just drop to the ground
			Vector3 newVelocity = new Vector3(0, -4f, 0);

			rb.velocity = newVelocity;

			gameObject.layer = LayerMask.NameToLayer("Falling");
		}

		// do nothing if colliding with scissors
	}
}
