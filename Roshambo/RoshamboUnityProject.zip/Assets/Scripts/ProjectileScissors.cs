﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileScissors : MonoBehaviour {

	public Sprite closedScissors;

	public GameObject blueBrokenScissors;

	public GameObject redBrokenScissors;
	private SpriteRenderer spriteRenderer;

	private Rigidbody rb;

	private void Start() {
		rb = GetComponent<Rigidbody>();
		spriteRenderer = GetComponent<SpriteRenderer>();
	}

	private void OnTriggerEnter(Collider other) {
		if (other.tag == "Paper") {
			// have an advantage against paper
			
			// change to closed scissors
			spriteRenderer.sprite = closedScissors;

			// speed up scissors
			rb.velocity = rb.velocity * 2;
		}
		if (other.tag == "Scissors") {
			// ties Scissors

			Vector3 downward = new Vector3(0f, -3f, 0);
			rb.velocity = downward;

			gameObject.layer = LayerMask.NameToLayer("Falling");

			// TODO: play dink sound
		}
		if (other.tag == "Rock") {
			Debug.Log("rock beat scissors");
			// spawn broken scissors at a diagonal angle
			// goes back in other direction
			Vector3 brokenVelocity = rb.velocity * -1f;

			bool right = true;
			if (rb.velocity.x < 0f) {
				right = false;
			}

			Vector3 offset = Vector3.right*1f * (right ? -1:1);

			brokenVelocity.y = -3;

			GameObject red = GameObject.Instantiate(redBrokenScissors,
										 			other.transform.position + offset, 
													other.transform.rotation);

			red.GetComponent<Rigidbody>().velocity = brokenVelocity;

			brokenVelocity.y = 3;
			GameObject blue = GameObject.Instantiate(blueBrokenScissors,
										 			 other.transform.position + offset, 
										 			 other.transform.rotation);
			blue.GetComponent<Rigidbody>().velocity = brokenVelocity;

			// destroy scissors object
			GameObject.Destroy(this.gameObject);
		}
	}
}
