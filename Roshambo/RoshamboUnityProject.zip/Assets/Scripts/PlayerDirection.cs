﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class PlayerDirection : MonoBehaviour {

	public bool right = true;

	private InputDevice controller;

	private GameController gameController;

	void Start(){
		controller = InputManager.Devices[GetComponent<PlayerNum>().playerNum];
		gameController = GameObject.Find("GameController").GetComponent<GameController>();
	}
	
	// Update is called once per frame
	void Update () {

		// if (!gameController.ignoreInput) {
		// 	Vector3 rotation = new Vector3(0, 180, 0);

		// 	// Change player direction
		// 	if (right && controller.LeftStickX < 0) {
		// 		right = false;
		// 		transform.Rotate(rotation);
		// 	}
		// 	else if (!right && controller.LeftStickX > 0) {
		// 		right = true;
		// 		transform.Rotate(rotation);
		// 	}
		// }
	}
}
