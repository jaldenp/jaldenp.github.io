﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class PlayerJump : MonoBehaviour {
	Rigidbody rb;

	public LayerMask groundLayer;
	public LayerMask playerMask;

	public float rayCastDistance;

	public float jumpHeight;

	private float jumpCounter;
	public float maxJumpTime;
	
	private bool isJumping;

	private InputDevice controller;

	private GameController gameOver;

	private Animator animator;

	// Use this for initialization
	void Awake () {
		rb = GetComponent<Rigidbody>();
		Debug.Log(rb);
		isJumping = false;
		Debug.Log(GetComponent<PlayerNum>().playerNum);
		controller = InputManager.Devices[GetComponent<PlayerNum>().playerNum];
		gameOver = GameObject.Find("GameController").GetComponent<GameController>();
		animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
		if (!gameOver.ignoreInput) {
			Debug.DrawRay(transform.position, -Vector3.up * rayCastDistance, Color.red);

			// CREDIT for jump script: https://www.youtube.com/watch?v=j111eKN8sJw
			// space is jump
			if (IsGrounded() && controller.Action1) {
				animator.SetLayerWeight(2, 1);
				rb.velocity = Vector3.up * jumpHeight;
				jumpCounter = maxJumpTime;
				isJumping = true;
			}

			if (controller.Action1 && isJumping) {
				if (jumpCounter > 0) {
					rb.velocity = Vector3.up * jumpHeight;
					jumpCounter -= Time.deltaTime;
				}
				else {
					isJumping = false;
				}
			}
			if (controller.Action1.WasReleased) {
				isJumping = false;
			}
		}
	}

	// Function to Check if player is on the ground
	public bool IsGrounded(){
		if (Physics.Raycast(transform.position, -transform.up, rayCastDistance, groundLayer) ||
			Physics.Raycast(transform.position, -transform.up, rayCastDistance, playerMask)){
			//Debug.Log("on ground");
			animator.SetLayerWeight(2, 0);
			return true;
		}
		else {
			return false;
		}
	}
}
