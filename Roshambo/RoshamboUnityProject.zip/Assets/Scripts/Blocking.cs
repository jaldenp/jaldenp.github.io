﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blocking : MonoBehaviour {
	
	private PlayerHealth playerHealth;

	public string Weakness;
	public string Strength;

	// Use this for initialization
	void Awake () {
		playerHealth = transform.parent.GetComponentInParent<PlayerHealth>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.tag == Weakness) {
			// blocked a weakness, so take damage
			//playerHealth.takeDamage(5);
		}

		if (other.tag == Strength) {
			playerHealth.gainHealth(12);
		}
	}
}
