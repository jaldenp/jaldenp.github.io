﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RemoveColliderOnHit : MonoBehaviour {

	private BoxCollider box;

	private Rigidbody rb;

	// Use this for initialization
	void Start () {
		box = GetComponent<BoxCollider>();
		rb = GetComponent<Rigidbody>();
		rb.velocity = new Vector3(0f, -3f, 0f);

		StartCoroutine(DestroyObject());
	}
	
	private void OnTriggerEnter(Collider other) {
		if (other.tag == "Player") {
			box.enabled = false;
		}
	}

	IEnumerator DestroyObject(){
		yield return new WaitForSeconds(2.0f);
		Destroy(gameObject);
	}
}
