﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParryObj : MonoBehaviour {

	public float rotSpeed = 80;
	private void Update() {
        transform.Rotate(0, 0, 50 * Time.deltaTime * rotSpeed);
	}
	private void OnTriggerEnter2D(Collider2D other) {
		Debug.Log(other);
		if (other.tag == "Projectile") {
			Destroy(other.gameObject);
		}
	}
}
