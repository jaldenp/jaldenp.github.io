﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplodeDamage : MonoBehaviour {

	
	public int damage;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		Debug.Log("Trigger Entered");
		if(other.gameObject.layer == LayerMask.NameToLayer("Player1") ||
		   other.gameObject.layer == LayerMask.NameToLayer("Player2")) {
            other.GetComponent<PlayerHealth>().TakeDamage(damage);
        }
	}

	
}
