﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDamage : MonoBehaviour {

    public int damage;
	
	void OnTriggerEnter2D(Collider2D other) {
		if(other.gameObject.layer == LayerMask.NameToLayer("Player1") ||
		   other.gameObject.layer == LayerMask.NameToLayer("Player2")) {
            other.GetComponent<PlayerHealth>().TakeDamage(damage);
        }
		Destroy(this.gameObject);
	}
}
