﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Crusader_Legs : MonoBehaviour {

    //public movement variables
    public float move_speed = 5.0f;
    public float jump_height = 3.0f;
    public float grav = 5.0f;

    //private components
    private Rigidbody2D rb2d;
    private Collider2D col;
    private InputDevice control;

    //grounding variables
    private bool grounded;
    private float ground_cast = 0.1f;

    private Animator animator;

    public float dashSpeed;
    private bool charging = false;
    private bool canCharge = true;

    // Use this for initialization
    void Start() {
        control = InputManager.Devices[GetComponentInParent<playerInfo>().legControlNum];
        rb2d = GetComponentInParent<Rigidbody2D>();
        rb2d.gravityScale = grav;
        col = GetComponentInParent<Collider2D>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update() {
        Debug.Log(rb2d.velocity);
        if (!charging)
        {
            /**************************************************
            * Update Grounding - be precise in this
            **************************************************/
            Vector2 center = col.bounds.center;
            float height = col.bounds.size.y;
            float width = col.bounds.size.x;

            LayerMask mask = LayerMask.NameToLayer("Map");
            Physics2D.queriesStartInColliders = false;
            Vector2 pos = new Vector2(center.x, center.y - (height / 2));
            grounded = Physics2D.Raycast(pos, Vector2.down, ground_cast, 1 << mask);
            pos = new Vector2(center.x - (width / 2), center.y - (height / 2));
            grounded = grounded || Physics2D.Raycast(pos, Vector2.down, ground_cast, 1 << mask);
            pos = new Vector2(center.x + (width / 2), center.y - (height / 2));
            grounded = grounded || Physics2D.Raycast(pos, Vector2.down, ground_cast, 1 << mask);

            /**************************************************
            * Update Movement
            **************************************************/
            Vector2 move = rb2d.velocity;

            float x_input = control.LeftStick.X;
            float y_input = control.LeftStick.Y;

            //flip object to face the right way
            if (Mathf.Abs(rb2d.velocity.x) > 0) {
                Quaternion rot = transform.rotation;
                transform.rotation = Quaternion.Euler(rot.x, Mathf.Sign(rb2d.velocity.x) == 1 ? 0 : 180, rot.z);
            }
            move.x = move_speed * x_input;

            if (move.x != 0) {
                animator.SetLayerWeight(1, 1);
            }
            else {
                animator.SetLayerWeight(1, 0);
            }

            // dash
            if (control.Action3 && grounded && canCharge) {
                charging = true;
                canCharge = false;
                StartCoroutine(Charging());
            }

            // jumping
            if (control.Action1.WasPressed && grounded)
                move.y = Mathf.Sqrt(-2.0f * (Physics2D.gravity.y * rb2d.gravityScale) * jump_height);
            else if (control.Action1.WasReleased && rb2d.velocity.y > 0) // cancel jump
                move.y = move.y * 0.5f;

            //set the velocity
            rb2d.velocity = move;
        }
        else {
            Vector2 newSpeed = rb2d.velocity;
            newSpeed.x = dashSpeed * (transform.rotation.y == 1.0f ? -1: 1);
            rb2d.velocity = newSpeed;
        }
    }

    IEnumerator Charging () {
        yield return new WaitForSeconds(0.5f);
        charging = false;
        StartCoroutine(ChargeCooldown());
    }

    IEnumerator ChargeCooldown() {
        yield return new WaitForSeconds(1.0f);
        canCharge = true;
    }
}
