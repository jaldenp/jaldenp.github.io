﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class GravityLegs : MonoBehaviour {
    Rigidbody2D rb;
    public float movement_velocity = 1.0f;
    Transform tf;
	public GameObject placeholder;
	public float gravityForce = -9.8f;

	InputDevice controller;
	public float smooth = 5;
	Quaternion target = Quaternion.Euler(0, 0, 0);

	private void Awake() {
		tf = transform.parent;
		rb = GetComponentInParent<Rigidbody2D>();
        controller = InputManager.Devices[GetComponentInParent<playerInfo>().legControlNum];
		rb.gravityScale = 0;
	}

	private void Update() {
		if (controller.Action1.WasPressed) target = Quaternion.Euler(0, 0, 0);
		else if (controller.Action2.WasPressed) target = Quaternion.Euler(0, 0, 90);
		else if (controller.Action4.WasPressed) target = Quaternion.Euler(0, 0, 180);
		else if (controller.Action3.WasPressed) target = Quaternion.Euler(0, 0, 270);
        // Dampen towards the target rotation
		if (placeholder.transform.rotation != target) placeholder.transform.rotation = target;
        tf.rotation = Quaternion.Slerp(tf.rotation, target, Time.deltaTime * smooth);
		//Debug.DrawRay(tf.position, tf.right);

		
		rb.velocity = Vector3.Scale(new Vector2(Mathf.Abs(tf.right.x), Mathf.Abs(tf.right.y)), (Vector3) controller.LeftStick) * movement_velocity;

	}
	private void FixedUpdate() {
		//Debug.Log(target.eulerAngles);
		Vector2 force = gravityForce * placeholder.transform.up;
		rb.AddForce(force * rb.mass);
	}
}
