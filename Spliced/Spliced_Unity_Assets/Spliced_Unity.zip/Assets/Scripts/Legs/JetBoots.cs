﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class JetBoots : MonoBehaviour {

	public int playerNum = 0;

	private InputDevice controller;

	public float movementSpeed;
	public float jumpHeight;
	public float jumpDecrease;
	public float jetPower;
	public float jetSideWaysDistance;

	private Rigidbody2D rb2d;

	private bool grounded = true;

	private LayerMask groundMask;

	private Collider2D col;

	public float raycastLength = 0.1f;

	private int dodge = 0; // 1 for left, 2 for right
	private float dodgeDistance = 0;
	public float dodgeSpeed;

	private float maxFuel = 100;
	private float remainingFuel;

	public GameObject rocketFireGO;
	private SpriteRenderer fireSpriteRenderer;

	public List<Sprite> fireSprites;
	private bool outOfFuel = false;

	public float fuelRegenDelay = 2.0f;

	public float dodgeFuelAmount;
	public float rocketUpFuelAmount;

	public Sprite robotDodgeLegs;
	public Sprite robotLegs;
	private SpriteRenderer robotRenderer;

	public GameObject DodgeFireObject;

	private SpriteRenderer dodgeFireSprite;

	// Use this for initialization
	void Start () {
        playerNum = GetComponentInParent<playerInfo>().legControlNum;
		controller = InputManager.Devices[playerNum];
		rb2d = GetComponentInParent<Rigidbody2D>();
		col = GetComponentInParent<Collider2D>();
		groundMask = LayerMask.NameToLayer("Map");
		remainingFuel = maxFuel;
		fireSpriteRenderer = rocketFireGO.GetComponent<SpriteRenderer>();
		InvokeRepeating("RegenerateFuel", 0.0f, 0.3f);
		robotRenderer = GetComponent<SpriteRenderer>();
		dodgeFireSprite = DodgeFireObject.GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
			Vector2 move = rb2d.velocity;
			
			UpdateGrounded();

			UpdateFireSprite();

			if (grounded) {
				fireSpriteRenderer.enabled = false;
			}

			if (dodge != 0) {
				if (dodge != -1) {
					rb2d.velocity = Vector2.zero;
					if (dodgeDistance >= jetSideWaysDistance) {
						dodge = 0;
						dodgeDistance = 0;
						robotRenderer.sprite = robotLegs;
						DodgeFireObject.SetActive(false);
					}
					else {
						// need to move in the correct direction
						float tempDistance = 1.0f * Time.deltaTime * dodgeSpeed;
						dodgeDistance += tempDistance;
						tempDistance *= ((dodge == 1) ? -1: 1);
						Vector2 newPosition = transform.parent.position;
						newPosition.x += tempDistance;
						transform.parent.position = newPosition;
					}
				}
			}
			else {
				float x_input = controller.LeftStick.X;
				float y_input = controller.LeftStick.Y;

				//flip object to face the right way
				if (Mathf.Abs(rb2d.velocity.x) > 0) {
					Quaternion rot = transform.rotation;
					transform.rotation = Quaternion.Euler(rot.x, Mathf.Sign(rb2d.velocity.x) == 1 ? 0 : 180, rot.z);
				}
				move.x = movementSpeed * x_input;

				// jumping
				if (controller.Action1.WasPressed && grounded) {
					move.y = Mathf.Sqrt(-jumpHeight * (Physics2D.gravity.y * rb2d.gravityScale));
				}
				else if (controller.Action1.WasReleased && rb2d.velocity.y > 0) {
					// cancel jump
					move.y = move.y * jumpDecrease;
				}

				// JET BOOTS DODGE
				if (controller.Action2 && !grounded) {
					StartDodge(2);
				}
				else if (controller.Action3 && !grounded) {
					StartDodge(1);
				}
				
				//set the velocity
				rb2d.velocity = move;
			}
	}

	void FixedUpdate() {
		// JET BOOTS
		if (controller.Action1 && !grounded) {
			fireSpriteRenderer.enabled = true;
			if (!outOfFuel) {
				UseFuel(rocketUpFuelAmount);
				if (rb2d.velocity.y < 0) {
					// triple the force to counteract gravity
					rb2d.AddForce(Vector2.up * jetPower * 8);
				}
				else {
					rb2d.AddForce(Vector2.up * jetPower);
				}
			}
		}
		else if (!grounded) {
			fireSpriteRenderer.enabled = false;
		}
	}

	private void UpdateGrounded() {
		Vector2 center = col.bounds.center;
        float height = col.bounds.size.y;
        float width = col.bounds.size.x;

        Physics2D.queriesStartInColliders = false;
        Vector2 pos = new Vector2(center.x, center.y - (height / 2));
        grounded = Physics2D.Raycast(pos, Vector2.down, raycastLength, 1 << groundMask);
        pos = new Vector2(center.x - (width / 2), center.y - (height / 2));
        grounded = grounded || Physics2D.Raycast(pos, Vector2.down, raycastLength, 1 << groundMask);
        pos = new Vector2(center.x + (width / 2), center.y - (height / 2));
        grounded = grounded || Physics2D.Raycast(pos, Vector2.down, raycastLength, 1 << groundMask);

		Debug.DrawRay(pos, Vector2.down * raycastLength, Color.red);
	}

	private void StartDodge(int type) {
		// type is 1 for dodge left or 2 for dodge right
		dodge = type;
		robotRenderer.sprite = robotDodgeLegs;
		transform.rotation = Quaternion.Euler(0, (type == 1) ? 0: 180, 0);
		DodgeFireObject.SetActive(true);
		if (remainingFuel < dodgeFuelAmount) {
			StartCoroutine(DodgeSmoke());
		}
		else {
			UseFuel(dodgeFuelAmount);
		}
	}

	IEnumerator DodgeSmoke() {
		dodge = -1;
		dodgeFireSprite.sprite = fireSprites[6];
		yield return new WaitForSeconds(0.15f);
		robotRenderer.sprite = robotLegs;
		dodgeFireSprite.sprite = fireSprites[5];
		dodge = 0;
		DodgeFireObject.SetActive(false);
	}

	private void UseFuel(float amount) {
		if (!outOfFuel) {
			remainingFuel -= amount;
			if (remainingFuel <= 0) {
				remainingFuel = 0;
				outOfFuel = true;
				StartCoroutine(FuelDelay());
			}
		}
	}

	private void RegenerateFuel() {
		Debug.Log("regenerating fuel");
		// Regenrates 10% of fuel every second
		if (!outOfFuel && (remainingFuel < maxFuel)) {
			remainingFuel += 10.0f;
			if (remainingFuel > maxFuel) {
				remainingFuel = maxFuel;
			}
		}
	}
	private void UpdateFireSprite() {
		// updates the fire sprite based on value of remainingFuel
		if (remainingFuel > (maxFuel / 2)) {
			// full sprite
			fireSpriteRenderer.sprite = fireSprites[0];
		}
		else if (remainingFuel > (maxFuel / 4)) {
			// half sprite
			fireSpriteRenderer.sprite = fireSprites[1];
		}
		else if (remainingFuel > 0.0f) {
			// quarter sprite
			fireSpriteRenderer.sprite = fireSprites[2];
		}
		else {
			// smoke sprite
			fireSpriteRenderer.sprite = fireSprites[4];
		}
	}

	IEnumerator FuelDelay() {
		yield return new WaitForSeconds(fuelRegenDelay);
		outOfFuel = false;
	}
}
