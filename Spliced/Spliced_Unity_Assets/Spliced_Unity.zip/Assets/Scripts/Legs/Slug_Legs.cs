﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Slug_Legs : MonoBehaviour
{

    Rigidbody2D rb;
    public float movement_velocity = 1.0f;

	public float prevDir;
	bool zooming;
	bool canZoom = true;
    bool rotBack;
	bool goingUp;
	public Vector3 upDir;
	public LayerMask ground_layer;
	private Vector3 zoomOrigin;
	// // Animator anim;
	private float zoomDelta = 4;
	InputDevice controller;
	public float zoomCoolDownTime = 1.5f;
	public float zoomVelocity = 14f;


	Collider2D col;
	GameObject torso;
	
	Transform tf;
	IEnumerator zoomCoolDown() {
		canZoom = false;		
		yield return new WaitForSecondsRealtime(zoomCoolDownTime);
		canZoom = true;
	}
    void Awake()
    {
        foreach (Transform child in transform.parent)
        {
            if (child.name != this.name && child.name != "bird")
            {
                Debug.Log("Found sibling " + child.name);
				torso = child.gameObject;

                // work with child here
            }
        }
		// transform = GetComponent<Transform>();
		col = GetComponentInParent<Collider2D>();
        rb = GetComponentInParent<Rigidbody2D>();
		tf = transform.parent;
		controller = InputManager.Devices[GetComponentInParent<playerInfo>().legControlNum];
		// controller = InputManager.ActiveDevice;
		rb.gravityScale = 0;
		prevDir = -1;
		// anim = GetComponent<Animator>();
		Debug.Log("Start");
    }
	private void OnEnable() {
        // anim = GetComponent<Animator>();
		tf.rotation = Quaternion.identity;
		rb.gravityScale = 0;
		if (prevDir == -1)
			Flip180Y();
			// Flip180Z();
		canZoom = true;
		zooming = false;
		goingUp = false;
		// anim.SetBool("zooming", false);
		// Debug.Log(prevDir);
	}
	private void OnDisable() {
        float direction = rb.velocity.x;
        if (direction > 0)
            direction = 1;
        else if (direction <= 0)
            direction = -1;
		tf.root.localScale = new Vector3(direction, 1, 1);
	
	}
		
    // Update is called once per frame
    void Update()
    {
        float direction = controller.GetControl(InputControlType.LeftStickX);
		upDir = tf.up;
		// float direction = Input.GetAxis("Horizontal"); 
		if (direction > 0)
			direction = 1;
		else if (direction < 0)
			direction = -1;
		if (rb.gravityScale == 0) {
			if (zooming) {
				if (Vector3.Distance(zoomOrigin, tf.position) >= 4) {

					zooming = false;
                    // anim.SetBool("zooming", false);
					if (rotBack) {
						if (goingUp)
							Flip180Z();
						if (!goingUp)
                        	// tf.Rotate(0, 180, 0);
							Flip180Y();
						// goingUp = false;
                        rotBack = false;
					}
					if(!goingUp && !Physics2D.Raycast(tf.position, -tf.up, col.bounds.extents.y + .2f, ground_layer)) {
						zooming = true;
                        // anim.SetBool("zooming", true);
						zoomOrigin = tf.position;
                        // tf.Rotate(0, 180, 0);
						Flip180Y();
						rotBack = true;
					} 
					if (goingUp) {
						zooming = true;
						zoomOrigin = tf.position;
						// tf.Rotate(180,0,0);
						Flip180Z();
						// rotBack = true;
					}
					StartCoroutine("zoomCoolDown");
				}
				else if (!goingUp) {
					rb.velocity = tf.right * zoomVelocity;
				}
				else {
					rb.velocity = tf.up * zoomVelocity;
				}
			}
			else {
			if ((prevDir > 0 && direction < 0) || (prevDir < 0 && direction > 0))
				// tf.Rotate(0, 180, 0);
				Flip180Y();
		
			if (direction != 0)
				rb.velocity = tf.right * movement_velocity;
			else 
				rb.velocity = Vector3.zero;
			if(direction != 0)
				prevDir = direction;
			}
		}

		
    }

    void FixedUpdate()
    {
		// Debug.Log(goingUp);
        bool aDown = controller.Action1.WasPressed;
        bool xDown = controller.Action3.WasPressed || controller.Action2.WasPressed;

        if (rb.gravityScale == 0) {
			if ((xDown || aDown) && !zooming && canZoom) {
				zooming = true;
				goingUp = aDown;
                // anim.SetBool("zooming", true);
				zoomOrigin = tf.position;

			}
			if (zooming && !goingUp) {
				if (Physics2D.Raycast(tf.position, tf.right, 0.6f, ground_layer)) {
					zooming = false;
                    // anim.SetBool("zooming", false);
					rb.velocity = Vector3.zero;
					// tf.Rotate(0, 0, 90);
					Flip90Z();
				}

			}
			if (zooming && goingUp) {
				RaycastHit2D rch = Physics2D.Raycast(tf.position, tf.up, (col.bounds.extents.y * 2) + 1.0f, ground_layer);
                if (rch)
                {
					Debug.Log(rch.distance);
					Debug.Log(rch.point);
					Debug.Log(rch.normal);
					// tf.position = rch.point;
                    // tf.Rotate(180, 0, 0);
					Flip180Z();
                    zooming = false;
                    while (!Physics2D.Raycast(tf.position, -tf.up, .05f, ground_layer))
                    {
                        tf.root.position -= tf.up * .025f;
                    }
                    // anim.SetBool("zooming", false);
                    rb.velocity = Vector3.zero;
					goingUp = false;
                }
			}
			if (!zooming) {

				bool hasMoved = false;
				Vector3 direction = tf.right;
				// Vector3 downSource = col.bounds.center - direction * col.bounds.extents.y;
				// Is something beneath us?
				if (!Physics2D.Raycast(tf.position, -tf.up, col.bounds.extents.y + .2f, ground_layer))
				{
					// Debug.Log("nothing beneath us");
					// tf.Rotate(0, 0, -90);
					FlipNeg90Z();
					Vector3 relativePos = tf.position;

					tf.root.position += tf.up * .25f + tf.right * 0.7f;
					hasMoved = true;
					
					// tf.position = relativePos;
					// tf.position = Vector3.zero;
				}

				// Is something in front of us?
				if (Physics2D.Raycast(tf.position, tf.right, 0.6f, ground_layer) && !hasMoved)
				{
					
					Debug.Log("something in front of us");
					Flip90Z();
					Vector3 relativePos = tf.position;
					
					// tf.position = Vector3.zero;
				}
				// readjust if we're a little ways off the ground
				if (Physics2D.Raycast(tf.position, -tf.up, col.bounds.extents.y + .2f, ground_layer) && !Physics2D.Raycast(tf.position, -tf.up, col.bounds.extents.y + .05f, ground_layer) && !hasMoved) {
					tf.root.position -= tf.up *.15f;
				}
			}
			// tf.localPosition = Vector3.zero;
			tf.root.position = new Vector3(tf.root.position.x, tf.root.position.y, 0);
		}
		else {
			while(tf.up != Vector3.up) {
				// tf.Rotate(0,0,90);
				Flip90Z();
			}
		}
    }
   
    // we need to flip the parent collider, 
    // while maintaining the transform direction of the child

    void Flip180Z() {
		tf.Rotate(0, 0, 180);
        // flip sprite to follow, unflip torso
        // torso.transform.Rotate(0, 0, -180);
        // SpriteRenderer sr = torso.GetComponent<SpriteRenderer>();
        torso.transform.GetChild(0).Rotate(0, 0, -180);
	}

	void Flip180Y() {
		tf.Rotate(0, 180, 0);
        // flip sprite to follow, unflip torso
		// torso.transform.GetChild(0).rotation = Quaternion.identity;
        // SpriteRenderer sr = torso.GetComponent<SpriteRenderer>();
        // sr.flipX = !sr.flipX;
        torso.transform.GetChild(0).Rotate(0, -180, 0);
    }
	void Flip90Z() {
		tf.Rotate(0, 0, 90);
        // torso.transform.Rotate(0, 0, -90);
        // // flip sprite to follow, unflip torso
        // SpriteRenderer sr = torso.GetComponent<SpriteRenderer>();
        // torso.transform.GetChild(0).rotation = Quaternion.identity;
        torso.transform.GetChild(0).Rotate(0, 0, -90);
    }
    void FlipNeg90Z()
    {
        tf.Rotate(0, 0, -90);
        // SpriteRenderer sr = torso.GetComponent<SpriteRenderer>();
        // flip sprite to follow, unflip torso
        // torso.transform.GetChild(0).rotation = Quaternion.identity;
        torso.transform.GetChild(0).Rotate(0, 0, 90);
    }
}
