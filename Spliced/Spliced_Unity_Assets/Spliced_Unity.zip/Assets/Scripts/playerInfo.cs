﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerInfo : MonoBehaviour {
	public int legControlNum = 0;
	public int torgoControlNum = 1;

	public int characterNumber;

}
