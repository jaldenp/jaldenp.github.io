﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour {

	private int startHealth = 100;

	private int health;
	
	

	public float iframeLength;

	public GameObject healthBarObject;
	private Slider healthSlider;

	private bool invincible = false;

	private playerInfo pInfo;

	// Use this for initialization
	void Awake () {
		health = startHealth;
		healthSlider = healthBarObject.GetComponent<Slider>();
		pInfo = GetComponent<playerInfo>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private IEnumerator iframes() {
		invincible = true;

		yield return new WaitForSeconds(iframeLength);

		invincible = false;
	}

	public void TakeDamage(int damage) {
		if (!invincible) {


			//Handheld.Vibrate();
			// decrement health
			health -= damage;

			// change health bar
			healthSlider.value = ((float) health / startHealth) * startHealth;

			// iframes
			iframes();

			// TODO: knockback

			if (health <= 0) {
				// call game over of game controller
				GameController.instance.GameOver(pInfo.legControlNum);

				healthSlider.value = 0;
			}
		}
	}
}
