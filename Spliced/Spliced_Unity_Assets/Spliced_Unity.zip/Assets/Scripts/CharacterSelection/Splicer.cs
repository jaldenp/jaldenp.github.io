﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Splicer : MonoBehaviour {

    public Fighter f1, f2, f3, f4;
    public GameObject BaseFighter;

    static Splicer instance;

    private void Awake() {
        if (instance == null)
            instance = this;
    }

    private void Start() {
        if (instance != this)
            Destroy(this.gameObject);
        DontDestroyOnLoad(this.gameObject);
    }

    public void SetFighter(int choice, Fighter fighter) {
        switch (choice) {
            case 0:
                f1 = fighter;
                break;
            case 1:
                f2 = fighter;
                break;
            case 2:
                f3 = fighter;
                break;
            case 3:
                f4 = fighter;
                break;
        }

        //if all are set, load next scene
        SceneManager.LoadScene("");
    }

    public void Splice() {
        //Team 1
        GameObject player1 = Instantiate(BaseFighter);
        player1.GetComponent<playerInfo>().characterNumber = 1;
        GameObject torso1 = Instantiate(f1.torso, player1.transform);
        GameObject legs1 = Instantiate(f2.legs, player1.transform);
        torso1.transform.position = new Vector3(0, 1, 0);

        //Team 2
        GameObject player2 = Instantiate(new GameObject());
        player2.GetComponent<playerInfo>().characterNumber = 2;
        GameObject torso2 = Instantiate(f3.torso, player2.transform);
        GameObject legs2 = Instantiate(f4.legs, player2.transform);
        torso2.transform.position = new Vector3(0, 1, 0);
    }
}
