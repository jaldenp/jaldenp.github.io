﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//the fighter is basically a struct to hold a torso and legs for splicing
public class Fighter : MonoBehaviour {
    public GameObject torso;
    public GameObject legs;
    public Sprite torso_sprite, legs_sprite;
}
