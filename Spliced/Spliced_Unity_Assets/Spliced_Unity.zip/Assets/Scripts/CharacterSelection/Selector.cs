﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Selector : MonoBehaviour {

    public List<Fighter> fighters;
    private int choice = 0;
    public int player_num;
    public SpriteRenderer torso, legs;

    private InputDevice control;

    // Use this for initialization
    void Start () {
        SetSprite();
        control = InputManager.Devices[player_num];
    }
	
	// Update is called once per frame
	void Update () {
        if (control.LeftStick.HasChanged) {
            float x = control.LeftStick.X;
            //go right
            if (x > 0)
                choice = (choice + 1) % fighters.Count;
            else if (x < 0) {
                choice = (choice - 1);
                if (choice < 0)
                    choice = fighters.Count - 1;
            }
            Debug.Log(choice);
            SetSprite();
        }

        //confirm selection
        if (control.Action1.WasPressed) {
            FindObjectOfType<Splicer>().SetFighter(player_num, fighters[choice]);
        }
    }

    void SetSprite() {
        torso.sprite = fighters[choice].torso_sprite;
        legs.sprite = fighters[choice].legs_sprite;
    }
}
