﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class exTorso : Torso {
	protected override void Fire() {
		Instantiate(projectile);
	}
}
