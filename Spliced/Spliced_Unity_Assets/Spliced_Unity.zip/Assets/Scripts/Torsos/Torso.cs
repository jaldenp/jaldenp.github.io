﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public abstract class Torso : MonoBehaviour {

    public GameObject projectile, weapon;
    public GameObject parryObj;
    public Transform  aim;
    public float projectile_speed;
    public float between_fire = 1.0f;
    public float between_parry = 1.0f;
    public float parryTime = .3f;
    private float since_fire = 1.0f;
    private float since_parry = 1.0f;
    Rigidbody2D rb;

    public InputDevice control;

    public LayerMask weapon_layer;

    //start
    void Start() {
        control = InputManager.Devices[GetComponentInParent<playerInfo>().torgoControlNum];
        rb = GetComponentInParent<Rigidbody2D>();
        if (GetComponentInParent<playerInfo>().characterNumber == 1) {
            weapon_layer = LayerMask.NameToLayer("HurtPlayer2");
        }
        else {
            weapon_layer = LayerMask.NameToLayer("HurtPlayer1");
        }
    }

    // Update is called once per frame
    void Update() {
        since_fire += Time.deltaTime;
        since_parry += Time.deltaTime;
        if (control.RightTrigger.WasPressed && since_fire >= between_fire && !GameController.instance.isGameOver) {
            Fire();
            since_fire = 0;
        }
        else if (control.LeftTrigger.WasPressed && since_parry >= between_parry && !GameController.instance.isGameOver)
        {
            StartCoroutine("Parry");
            since_parry = 0;
        }

    }

    protected abstract void Fire();
    private IEnumerator Parry() {
        weapon.SetActive(false);
        // float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg
        GameObject temp = Instantiate(parryObj, aim.position, aim.rotation, aim);
        // GameObject temp = Instantiate(parryObj, aim.position, aim.rotation, transform);
        // Debug.Break();
        temp.transform.position = temp.transform.position - aim.right * .1f;
        // Debug.Break();
        yield return new WaitForSeconds(parryTime);
        Destroy(temp);
        weapon.SetActive(true);
    }
}
