﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Torso_Aim : MonoBehaviour {

    public Transform body;
    public float rotation_speed = 15.0f;

    public SpriteRenderer torso_sprite;
    public SpriteRenderer weapon_sprite;
    private InputDevice controller;

    void Start() {
        //torso_sprite = GetComponentInParent<SpriteRenderer>();
        //weapon_sprite = GetComponent<SpriteRenderer>();
        controller = InputManager.Devices[GetComponentInParent<playerInfo>().torgoControlNum];
    }
    
    // Update is called once per frame
    void Update() {
        float x_input = controller.RightStick.X;
        float y_input = controller.RightStick.Y;
        
        Vector2 aim = new Vector2(x_input, y_input);
        if (aim != Vector2.zero) {
            //rotate the body based on the current velocity
            Vector2 dir = (body.position + new Vector3(aim.x, aim.y, 0)) - body.position;
            body.rotation = Quaternion.Lerp(body.rotation, Quaternion.Euler(0, 0, Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg), Time.deltaTime * rotation_speed);
        }
        
        //flip sprite left
        if (Mathf.Abs(transform.eulerAngles.z) > 90 && transform.eulerAngles.z < 270) {
            
            torso_sprite.flipX = true;
            weapon_sprite.flipY = true;
        }
        //rotate right
        else {
            torso_sprite.flipX = false;
            weapon_sprite.flipY = false;
        }
    }
}
