﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Crusader_Torso : MonoBehaviour {

	public GameObject ability1;
	public GameObject ability2;

	
	
	private InputDevice controller;
	// Use this for initialization
	void Start () {
		//ontroller = InputManager.Devices[playerNum];
		controller = InputManager.Devices[GetComponentInParent<playerInfo>().torgoControlNum];
	}
	
	// Update is called once per frame
	void Update () {
		if(controller.Action1)
		{
			if(!ability1.GetComponent<sword>().inSwing)
			{
				ability1.GetComponent<sword>().swing();
			}
			
		}
	}

	public virtual void ACTION(){}
}
