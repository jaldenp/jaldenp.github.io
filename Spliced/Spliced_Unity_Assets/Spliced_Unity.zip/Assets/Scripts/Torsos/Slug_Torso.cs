﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Slug_Torso : MonoBehaviour {

    public GameObject arrow;
    public Transform bow, aim;
    public float arrow_speed;
    public float fire_rate = 1.0f;
    private float since_fire = 1.0f;

    private InputDevice control;
    
    private LayerMask arrowLayer;

    //start
    void Start() {
        control = InputManager.Devices[GetComponentInParent<playerInfo>().torgoControlNum];

        if (GetComponentInParent<playerInfo>().characterNumber == 1) {
            arrowLayer = LayerMask.NameToLayer("HurtPlayer2");
        }
        else {
            arrowLayer = LayerMask.NameToLayer("HurtPlayer1");
        }
    }

	// Update is called once per frame
	void Update () {
        since_fire += Time.deltaTime;
        if (control.Action3.WasPressed && since_fire >= fire_rate && !GameController.instance.isGameOver) {
            since_fire = 0;
            GameObject temp = Instantiate(arrow, aim.position, Quaternion.identity);
            temp.transform.position = temp.transform.position -  aim.forward * .5f;
            // set layer of arrow
            temp.layer = arrowLayer;

            //set velocity
            temp.GetComponent<Rigidbody2D>().velocity = (aim.position - bow.position).normalized * arrow_speed;
        }
	}
}
