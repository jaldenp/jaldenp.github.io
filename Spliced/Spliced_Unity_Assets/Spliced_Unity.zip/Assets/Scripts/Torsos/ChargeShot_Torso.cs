﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class ChargeShot_Torso : Torso {

    public float max_scale = 1.5f;
    public float charge_rate = 0.25f;
    public int base_damage = 15;

    protected override void Fire() {
        StartCoroutine(Charge());
    }

    IEnumerator Charge() {
        //spawn in the beam
        GameObject temp = Instantiate(projectile, aim.position, Quaternion.identity);
        temp.GetComponent<Collider2D>().enabled = false;
        // set layer of arrow
        temp.layer = weapon_layer;
        //charge the beam up and make it bigger
        while (control.RightTrigger.IsPressed) {
            temp.transform.position = aim.position;
            if(temp.transform.localScale.x < max_scale) {
                temp.transform.localScale += (Vector3.one * charge_rate * Time.deltaTime);
            }
            else {
                temp.transform.localScale = new Vector3(max_scale, max_scale, max_scale);
            }
            yield return new WaitForEndOfFrame();
        }
        //release the beam and let it rip
        //set damage
        float dmg = base_damage * temp.transform.localScale.x;
        temp.GetComponent<PlayerDamage>().damage = (int)dmg;

        //set velocity
        temp.GetComponent<Rigidbody2D>().velocity = (aim.position - weapon.transform.position).normalized * projectile_speed;
        temp.GetComponent<Collider2D>().enabled = true;
    }
}
