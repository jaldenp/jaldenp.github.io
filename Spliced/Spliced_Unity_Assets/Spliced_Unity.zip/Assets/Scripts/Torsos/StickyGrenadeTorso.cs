﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StickyGrenadeTorso : Torso {

	// Use this for initialization
	

	protected override void Fire()
	{
		Debug.Log("StickyGrenadeTorso Fire Function Called");
		GameObject newGrenade = GameObject.Instantiate(projectile, aim.position, Quaternion.identity);
		newGrenade.layer = LayerMask.NameToLayer("HurtPlayer");
		newGrenade.GetComponent<Rigidbody2D>().velocity = (aim.position - weapon.transform.position).normalized * projectile_speed;

	}
}
