﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlugBolt : MonoBehaviour {

    private Rigidbody2D rb2d;
    private SpriteRenderer sprite;

    // Use this for initialization
    void Awake() {
        rb2d = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void FixedUpdate() {
        Vector2 dir = rb2d.velocity;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    void OnTriggerEnter2D(Collider2D col) {
        Destroy(this.gameObject);
    }
    /*
    void OnCollisionEnter2D(Collision2D collision) {
        Destroy(this.gameObject);
    }
    */
}
