﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

public class Arrow : MonoBehaviour {

	public GameObject arrow;
    public Transform bow, aim;
    public float arrow_speed;

    private InputDevice control;

	private LayerMask arrowLayer;
	
	public float fire_rate = 1.0f;
    private float since_fire = 1.0f;
    

    //start
    void Start() {
        control = InputManager.Devices[GetComponentInParent<playerInfo>().torgoControlNum];
		if (GetComponentInParent<playerInfo>().characterNumber == 1) {
            arrowLayer = LayerMask.NameToLayer("HurtPlayer2");
        }
        else {
            arrowLayer = LayerMask.NameToLayer("HurtPlayer1");
        }
	}

	// Update is called once per frame
	void Update () {
        since_fire += Time.deltaTime;
		if (control.Action3.WasPressed && !GameController.instance.isGameOver && since_fire >= fire_rate) {
            GameObject temp = Instantiate(arrow, aim.position, Quaternion.identity);
            //set velocity
			since_fire = 0;
			temp.layer = arrowLayer;
            temp.GetComponent<Rigidbody2D>().velocity = (aim.position - bow.position).normalized * arrow_speed;
        }
	}
}
