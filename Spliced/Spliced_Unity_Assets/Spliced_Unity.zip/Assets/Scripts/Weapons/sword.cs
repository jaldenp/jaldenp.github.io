﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sword : Crusader_Torso {

	public float duration;
	public float swingSpeed;
	public CapsuleCollider2D col;

	public bool inSwing = false;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		// if(Input.GetKeyDown(KeyCode.Mouse0))
		// {
		// 	if(!inSwing)
		// 	{
		// 		StartCoroutine(SwingSword());

		// 	}
		// }
		// if(this.GetComponent<SpriteRenderer>().flipY)
		// {
		// 	this.GetComponent<CapsuleCollider2D>().offset.Set(this.GetComponent<CapsuleCollider2D>().offset.x, this.GetComponent<CapsuleCollider2D>().offset.y - 1);
		// }
	}

	public override void ACTION()
	{
		
	}


	public void swing()
	{
		StartCoroutine(SwingSword());
	}
	IEnumerator SwingSword()
	{
		inSwing = true;
		col.enabled = true;
		if(this.GetComponent<SpriteRenderer>().flipY)
		{
			col.offset = new Vector2(col.offset.x, col.offset.y - 1);
		}
		float swingTime = 0;
		Quaternion returnRotation = this.transform.rotation;
		while(swingTime < duration)
		{
			if(this.GetComponent<SpriteRenderer>().flipY)
			{
				//Debug.Log("SPRITE IS FLIPPED ON Y MOVING COLLIDER");
				
				this.transform.rotation = Quaternion.Lerp(this.transform.rotation, Quaternion.Euler(0,0,-90), Time.deltaTime * swingSpeed);

			}
			else
			{
				this.transform.rotation = Quaternion.Lerp(this.transform.rotation, Quaternion.Euler(0,0,-90), Time.deltaTime * swingSpeed);

			}
			swingTime += Time.deltaTime;
			yield return new WaitForEndOfFrame();
		}
		StartCoroutine(SwingUp(returnRotation));

	}

	IEnumerator SwingUp(Quaternion swingBack)
	{
		float swingTime = 0;
		while(swingTime < duration)
		{
			this.transform.rotation = Quaternion.Lerp(this.transform.rotation, swingBack, Time.deltaTime * swingSpeed);
			swingTime += Time.deltaTime;
			yield return new WaitForEndOfFrame();
		}
		if(this.GetComponent<SpriteRenderer>().flipY)
		{
			//Debug.Log("MOVING COLLIDER BACK TO ");
			col.offset = new Vector2(col.offset.x, col.offset.y + 1);
		}
		col.enabled = false;
		inSwing = false;
	}
}
