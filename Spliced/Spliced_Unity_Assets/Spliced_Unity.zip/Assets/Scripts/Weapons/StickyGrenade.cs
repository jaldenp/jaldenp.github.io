﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StickyGrenade : MonoBehaviour {

	
	public float fuseLength;

	public GameObject explosion;

	public float CurrDur = 0.0f;

	private Animator Anim;
	private bool exploding = false;
	// Use this for initialization
	void Start () {
		StartCoroutine(explodeOnTime(fuseLength));
		Anim = this.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		Debug.Log("Detected collision");
		this.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
		this.GetComponent<Rigidbody2D>().gravityScale = 0;
		this.GetComponent<Rigidbody2D>().isKinematic = true;
		if(other.gameObject.layer == LayerMask.NameToLayer("Player1") ||
		   other.gameObject.layer == LayerMask.NameToLayer("Player2"))
		{
			this.transform.SetParent(other.transform);
			this.tag = "Untagged";
			
		}
		

	}

	IEnumerator explodeOnTime(float Timer)
	{

		while(Timer > 0)
		{
			Timer -= Time.deltaTime;
			yield return new WaitForEndOfFrame();
		}
		GameObject makeBoom = Instantiate(explosion, this.transform.position, Quaternion.identity);
		Destroy(this.gameObject);
		

	}

	
}
