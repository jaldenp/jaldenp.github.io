﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using InControl;
using UnityEngine.UI;

public class GameController : MonoBehaviour {
	// Singleton Game Controller Object

	public static GameController instance = null;

	public bool isGameOver = false;

	private InputDevice controller;

	public GameObject teamOneWin;
	public GameObject teamTwoWin;
	public GameObject restartGamePrompt;


	// Use this for initialization
	void Awake () {
		if (instance != null && instance != this) {
			Destroy(gameObject);
			return;
		}
		else {
			instance = this;

			// grab player 1's controller
			controller = InputManager.Devices[0];
		}
		Time.timeScale = 1;
		controller = InputManager.Devices[0];

	}
	
	void Start(){
		
	}
	// Update is called once per frame
	void Update () {
		if (isGameOver && controller.Action4.WasPressed) {
			isGameOver = false;
			Time.timeScale = 1;
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		}
	}

	public void GameOver(int loser) {
		// set game over bool to true
		isGameOver = true;
		// stop player control
		Time.timeScale = 0;

		// show game over UI
		if (loser == 0 || loser == 1) {
			// players 3 and 4 won
			teamTwoWin.SetActive(true);
		}
		else {
			teamOneWin.SetActive(true);
		}

		// show the restart game prompt
		restartGamePrompt.SetActive(true);
	}
}
