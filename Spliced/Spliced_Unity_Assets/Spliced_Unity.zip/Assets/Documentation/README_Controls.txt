Controls (Xbox Controller)

Player1 - Robot Legs (aka Jet Boots)
    left stick= movement
    a = jump / jet boots
    x = dash left (when in air)
    b = dash right (when in air)
    
Player2 - Astronaut Torso
    right stick = aim
    right-trigger = sticky grenade
    left-trigger = parry
    
Player3 - Astronaut Legs
    left stick= movement
    a = change gravity down
    x = change gravity left
    y = change gravity up
    b = change gravity right
    
Player4 - Robot torso
    right stick = aim
    right-trigger = charge shot (hold to charge)
    left-trigger = parry